<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login</title>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <!-- AOS Animation Library -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <style>
    body {
      margin: 0;
      padding: 0;
      background: linear-gradient(135deg, #00bfa5, #00796b);
      font-family: 'Poppins', sans-serif;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
    }

    .login-box {
      background-color: #ffffff;
      color: #333;
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
      width: 90%;
      max-width: 400px;
      text-align: center;
      position: relative;
    }

    h2 {
      margin-bottom: 25px;
      font-size: 28px;
      color: #00796b;
    }

    input {
      width: 100%;
      padding: 12px;
      margin-bottom: 20px;
      border-radius: 8px;
      border: 1px solid #ccc;
      font-size: 1rem;
      transition: border-color 0.3s ease;
    }

    input:focus {
      outline: none;
      border-color: #00bfa5;
    }

    button {
      background: linear-gradient(to right, #00bfa5, #00796b);
      border: none;
      padding: 12px 20px;
      font-size: 16px;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      width: 100%;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    button:hover {
      transform: translateY(-3px);
      box-shadow: 0 5px 15px rgba(0, 191, 165, 0.4);
    }

    .error {
      color: red;
      font-size: 0.9rem;
      margin-top: -10px;
      margin-bottom: 15px;
    }
  </style>
</head>
<body>

  <div class="login-box" data-aos="zoom-in">
    <h2>Admin Login</h2>
    <form id="loginForm">
      <input type="text" id="username" placeholder="Enter Admin Name" required />
      <input type="password" id="password" placeholder="Enter Password" required />
      <div id="errorMsg" class="error"></div>
      <button type="submit">Login</button>
    </form>
  </div>

  <!-- AOS Script -->
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init();

    const form = document.getElementById("loginForm");
    const errorMsg = document.getElementById("errorMsg");

    form.addEventListener("submit", function (e) {
      e.preventDefault();

      const username = document.getElementById("username").value.trim();
      const password = document.getElementById("password").value;

      if (username === "Admin" && password === "00007777") {
        window.location.href ="admin.php";
      } else {
        errorMsg.textContent = "Invalid Admin Name or Password";
      }
    });
  </script>
</body>
</html>
