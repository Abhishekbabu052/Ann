<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>MediKart HOME - Online Medical Store</title>

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet" />

  <!-- AOS Animation -->
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <!-- FontAwesome for social icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    html, body {
      font-family: 'Poppins', sans-serif;
      width: 100%;
      overflow-x: hidden;
      background-color: #f0fdfd;
      scroll-behavior: smooth;
    }
    /* Header */
    header {
      background-color: #0b7c88;
      padding: 1rem 2rem;
      color: white;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }
    .header-container {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1200px;
      margin: 0 auto;
    }
    .logo span {
      font-size: 2rem;
      font-weight: 600;
      animation: slideIn 1s ease-out forwards;
    }
    .welcome-container {
      display: flex;
      align-items: center;
      gap: 15px;
    }
    .welcome-message {
      font-size: 1.1rem;
      color: white;
    }
    .logout-btn {
      background: rgba(255, 255, 255, 0.2);
      color: white;
      border: none;
      padding: 8px 15px;
      border-radius: 4px;
      cursor: pointer;
      transition: background 0.3s;
      font-family: 'Poppins', sans-serif;
    }
    .logout-btn:hover {
      background: rgba(255, 255, 255, 0.3);
    }
    @keyframes slideIn {
      from { opacity: 0; transform: translateX(-50px); }
      to { opacity: 1; transform: translateX(0); }
    }
    /* Floating Admin Icon */
    .admin-icon {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 999;
      background: white;
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
    }
    .admin-icon img {
      width: 30px;
      height: 30px;
      transition: transform 0.3s ease;
    }
    .admin-icon:hover img {
      transform: scale(1.1);
    }
    /* Banner */
    .banner {
      height: 100vh;
      background: linear-gradient(rgba(11, 124, 136, 0.6), rgba(0, 0, 0, 0.6)),
        url('https://images.unsplash.com/photo-1588776814546-ec7c2f1da46f?auto=format&fit=crop&w=1500&q=80')
        no-repeat center center/cover;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
      text-align: center;
      padding: 0 1rem;
      position: relative;
    }
    .banner-overlay {
      max-width: 800px;
    }
    .banner-overlay h1 {
      font-size: 3.5rem;
      margin-bottom: 1rem;
      animation: fadeInDown 1s ease forwards;
    }
    .banner-overlay p {
      font-size: 1.5rem;
      margin-bottom: 2rem;
      animation: fadeInUp 1.2s ease forwards;
    }
    .banner button {
      margin-top: 1rem;
      padding: 1rem 2.5rem;
      background: linear-gradient(135deg, #00b7c5, #00798c);
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 1.1rem;
      font-weight: bold;
      cursor: pointer;
      transition: background 0.3s ease, transform 0.3s ease;
    }
    .banner button:hover {
      background: linear-gradient(135deg, #00798c, #00b7c5);
      transform: scale(1.05);
    }
    @keyframes fadeInDown {
      0% { opacity: 0; transform: translateY(-30px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    @keyframes fadeInUp {
      0% { opacity: 0; transform: translateY(30px); }
      100% { opacity: 1; transform: translateY(0); }
    }
    /* About Section */
    .about-section {
      padding: 5rem 2rem;
      background-color: #ffffff;
      max-width: 900px;
      margin: 0 auto;
      text-align: center;
      color: #0b7c88;
    }
    .about-section h2 {
      font-size: 2.5rem;
      margin-bottom: 2rem;
    }
    .about-section p {
      font-size: 1.2rem;
      line-height: 1.8;
      color: #333;
      max-width: 800px;
      margin: 0 auto;
    }
    /* Contact Section */
    .contact-section {
      padding: 5rem 2rem;
      background-color: #eef9fa;
      text-align: center;
    }
    .contact-container {
      max-width: 900px;
      margin: 0 auto;
    }
    .contact-icon {
      width: 60px;
      margin-bottom: 1.5rem;
    }
    .contact-section h2 {
      font-size: 2.5rem;
      margin-bottom: 2rem;
      color: #0b7c88;
    }
    .contact-section p {
      margin: 0.8rem 0;
      font-size: 1.1rem;
    }
    /* Footer */
    footer {
      background-color: #0b7c88;
      color: white;
      text-align: center;
      padding: 2rem 1rem;
    }
    .social-icons {
      margin: 1rem 0 1.5rem 0;
    }
    .social-icons a {
      color: white;
      margin: 0 15px;
      font-size: 1.8rem;
      transition: color 0.3s ease;
    }
    .social-icons a:hover {
      color: #a6e5eb;
      transform: translateY(-3px);
    }
    /* Responsive Design */
    @media (max-width: 768px) {
      .header-container {
        flex-direction: column;
        gap: 15px;
        text-align: center;
      }
      .welcome-container {
        flex-direction: column;
        gap: 10px;
      }
      .banner-overlay h1 {
        font-size: 2.5rem;
      }
      .banner-overlay p {
        font-size: 1.2rem;
      }
      .about-section, .contact-container {
        padding: 3rem 1.5rem;
      }
      .about-section h2, .contact-section h2 {
        font-size: 2rem;
      }
    }
    @media (max-width: 480px) {
      header {
        padding: 1rem;
      }
      .logo span {
        font-size: 1.8rem;
      }
      .banner-overlay h1 {
        font-size: 2rem;
      }
      .banner-overlay p {
        font-size: 1rem;
      }
      .banner button {
        padding: 0.8rem 1.8rem;
        font-size: 1rem;
      }
      .admin-icon {
        top: 15px;
        right: 15px;
        width: 40px;
        height: 40px;
      }
      .admin-icon img {
        width: 24px;
        height: 24px;
      }
    }
  </style>
</head>
<body>

  <!-- Floating Admin Icon -->
  <div class="admin-icon">
    <a href="login.php"><img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Admin" title="Admin Panel" /></a>
  </div>

  <!-- Header -->
  <header>
    <div class="header-container">
      <div class="logo">
        <span>MediKart</span>
      </div>
      <?php
      session_start();
      if (isset($_SESSION['username'])) {
          $username = htmlspecialchars($_SESSION['username']);
          echo '<div class="welcome-container">';
          echo '<div class="welcome-message">Welcome, ' . $username . '!</div>';
          echo '<form method="post" action="index.php">';
          echo '<button type="submit" class="logout-btn">Logout</button>';
          echo '</form>';
          echo '</div>';
      }
      ?>
    </div>
  </header>

  <!-- Banner -->
  <section class="banner">
    <div class="banner-overlay">
      <h1>Welcome to MediKart</h1>
      <p>Your trusted source for medicines and healthcare</p>
      <button><a href="medicines.php" style="text-decoration:none;color:white;">Shop Now</a></button>
    </div>
  </section>

  <!-- About Us Section -->
  <section class="about-section" data-aos="fade-up">
    <h2>About Us</h2>
    <p>
      MediKart is dedicated to providing quality medicines and healthcare products online.
      We strive to make healthcare accessible and affordable for everyone. Our platform offers
      a wide range of products sourced from trusted manufacturers to ensure safety and efficacy.
      Customer satisfaction and well-being are our top priorities.
    </p>
  </section>

  <!-- Contact Section -->
  <section id="contact" class="contact-section">
    <div class="contact-container">
      <h2 data-aos="fade-up">Contact Us</h2>
      <img src="https://cdn-icons-png.flaticon.com/512/597/597177.png" alt="Contact Icon" class="contact-icon" />
      <p>Email: support@medikart.com</p>
      <p>Phone: +1 234 567 890</p>
      <p>Address: 123 Health Street, Wellness City</p>
    </div>
  </section>

  <!-- Footer -->
  <footer>
    <div class="social-icons">
      <a href="https://in.linkedin.com/in/abhin-k-das-7655b8379" target="_blank" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
      <a href="https://www.instagram.com/accounts/login/?next=%2Fjimbru_02_%2F&source=omni_redirect" target="_blank" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
      <a href="https://in.linkedin.com/in/aben-shijo-4205192a7" target="_blank" aria-label="LinkedIn"><i class="fab fa-linkedin"></i></a>
    </div>
    <p>&copy; 2025 MediKart. All rights reserved.</p>
  </footer>

  <!-- AOS Script -->
  <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
  <script>
    AOS.init({ duration: 800, once: true });
  </script>

</body>
</html>