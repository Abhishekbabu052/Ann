<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "medicine_store");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add medicine
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add"])) {
    $name = $_POST["name"];
    $price = $_POST["price"];
    $description = $_POST["description"];
    $image_name = $_FILES["image"]["name"];
    $image_tmp = $_FILES["image"]["tmp_name"];
    $image_path = "uploads/" . basename($image_name);

    if (move_uploaded_file($image_tmp, $image_path)) {
        $sql = "INSERT INTO medicine (image, name, price, description) 
                VALUES ('$image_path', '$name', '$price', '$description')";
        echo $conn->query($sql) 
            ? "<p class='success'>✅ Medicine added.</p>" 
            : "<p class='error'>❌ Error: " . $conn->error . "</p>";
    } else {
        echo "<p class='error'>❌ Image upload failed.</p>";
    }
}

// Edit medicine
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["edit"])) {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $price = $_POST["price"];
    $description = $_POST["description"];

    $sql = "UPDATE medicine 
            SET name='$name', price='$price', description='$description' 
            WHERE id=$id";
    echo $conn->query($sql) 
        ? "<p class='success'>✏️ Medicine updated.</p>" 
        : "<p class='error'>❌ Error: " . $conn->error . "</p>";
}

// Delete medicine
if (isset($_GET["id"])) {
    $id = intval($_GET["id"]);
    $conn->query("DELETE FROM medicine WHERE id=$id");
    echo "success";
} else {
    echo "error";
}

// Fetch orders
$orderResult = $conn->query("
    SELECT orders.*, medicine.name AS medicine_name 
    FROM orders 
    JOIN medicine ON orders.medicine_id = medicine.id
");

// Close connection
$conn->close();
?>
