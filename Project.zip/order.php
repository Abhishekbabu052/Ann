<?php
$conn = new mysqli("localhost", "root", "", "medicine_store");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get medicine details
$medicine_id = $_GET["id"];
$medicine = $conn->query("SELECT * FROM medicine WHERE id=$medicine_id")->fetch_assoc();

// Initialize message variable for feedback
$message = "";

// Handle order submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $address = $_POST["address"];
    $phone = $_POST["phone"];
    $pincode = $_POST["pincode"];
    $price = $_POST["price"];

    $sql = "INSERT INTO orders (medicine_id, name, price, address, phone, pincode)
            VALUES ('$medicine_id', '$name', '$price', '$address', '$phone', '$pincode')";
    if ($conn->query($sql) === TRUE) {
        $message = "<p class='message success'>✅ Order placed successfully.</p>";
    } else {
        $message = "<p class='message error'>❌ Error: " . $conn->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Order Medicine - MediKart</title>

<style>
body {
  font-family: 'Poppins', sans-serif;
  background-color: #f5fdfd;
  color: #333;
  padding: 2rem;
  max-width: 600px;
  margin: 2rem auto;
  box-sizing: border-box;
}

h2 {
  text-align: center;
  color: #00695c;
  margin-bottom: 1.5rem;
  font-weight: 600;
  font-size: 2rem;
}

img {
  display: block;
  margin: 0 auto 1rem;
  border-radius: 12px;
  box-shadow: 0 3px 12px rgba(0, 191, 165, 0.3);
}

strong {
  color: #00796b;
  font-weight: 600;
}

form {
  background: white;
  padding: 2rem;
  border-radius: 18px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

label {
  display: block;
  margin-bottom: 0.3rem;
  font-weight: 600;
  color: #004d40;
}

input[type="text"],
textarea {
  width: 100%;
  padding: 0.6rem 0.8rem;
  border: 2px solid #00bfa5;
  border-radius: 10px;
  font-size: 1rem;
  margin-bottom: 1.2rem;
  resize: vertical;
  transition: border-color 0.3s ease;
}

input[type="text"]:focus,
textarea:focus {
  border-color: #00796b;
  outline: none;
  box-shadow: 0 0 5px rgba(0, 191, 165, 0.4);
}

input[type="submit"] {
  background: linear-gradient(to right, #00bfa5, #00796b);
  color: white;
  border: none;
  padding: 12px 25px;
  font-size: 1.1rem;
  font-weight: 600;
  border-radius: 12px;
  cursor: pointer;
  width: 100%;
  transition: background 0.3s ease, box-shadow 0.3s ease;
}

input[type="submit"]:hover {
  background: linear-gradient(to right, #00796b, #004d40);
  box-shadow: 0 8px 20px rgba(0, 128, 128, 0.4);
}

.message {
  text-align: center;
  font-weight: 600;
  margin-top: 1rem;
}

.message.success {
  color: #2e7d32; /* green */
}

.message.error {
  color: #c62828; /* red */
}
</style>
</head>
<body>

<h2>Order Medicine</h2>

<img src="<?php echo htmlspecialchars($medicine["image"]); ?>" width="150" alt="Medicine Image"><br>

<strong>Name:</strong> <?php echo htmlspecialchars($medicine["name"]); ?><br>
<strong>Description:</strong> <?php echo htmlspecialchars($medicine["description"]); ?><br>
<strong>Price:</strong> ₹<?php echo htmlspecialchars($medicine["price"]); ?><br><br>

<?php
// Show success/error message if exists
echo $message;
?>

<form method="POST" novalidate>
    <input type="hidden" name="price" value="<?php echo htmlspecialchars($medicine["price"]); ?>">
    
    <label for="name">Your Name:</label>
    <input type="text" id="name" name="name" required>
    
    <label for="address">Address:</label>
    <textarea id="address" name="address" rows="3" required></textarea>
    
    <label for="phone">Phone:</label>
    <input type="text" id="phone" name="phone" required>
    
    <label for="pincode">Pincode:</label>
    <input type="text" id="pincode" name="pincode" required>
    
    <input type="submit" value="Place Order">
</form>

</body>
<script>
  document.querySelector('form').addEventListener('submit', function(e) {
    // Get all inputs and textarea
    const name = this.name.value.trim();
    const address = this.address.value.trim();
    const phone = this.phone.value.trim();
    const pincode = this.pincode.value.trim();

    if (!name || !address || !phone || !pincode) {
      e.preventDefault();
      alert('Please fill in all fields completely before submitting.');
    }
  });
</script>

</html>
